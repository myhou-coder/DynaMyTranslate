# Part I Sensor Technology
Humans must rely on sensory organs to obtain information from the external world. However, when studying natural phenomena, laws, and production activities, the functions of human sensory organs are far from sufficient. To adapt to this situation, sensors are required. It can be said that sensors are extensions of human senses and are also referred to as "electric sensory organs."
![](images/ab6cf1d1bb7d6df3506ee67f0b1eba2cd2544c98636adbb31c77aad6b3631a08.jpg)
With the advent of the new technological revolution, the world has entered the information age. In the process of utilizing information, the primary challenge is ensuring the accuracy of data acquisition, and sensors serve as the primary means to obtain information in both natural and industrial domains.  

In modern industrial production, particularly in automated processes, various sensors are employed to monitor and control production parameters, ensuring optimal equipment performance and the highest product quality. Thus, it can be said that without a multitude of high-quality sensors, modern production would lose its foundation.  

In fundamental scientific research, sensors play an even more prominent role. The advancement of modern science and technology has expanded into numerous new frontiers—from observing the vast universe spanning thousands of light-years at the macroscopic level to examining subatomic particles as small as femtometers (fm) at the microscopic level. Temporally, research ranges from tracking celestial evolution over hundreds of thousands of years to capturing instantaneous reactions as brief as seconds (s). Additionally, extreme technological research, such as ultra-high temperature, ultra-low temperature, ultra-high pressure, ultra-high vacuum, ultra-strong magnetic fields, and ultra-weak magnetic fields, has emerged as crucial for deepening our understanding of matter and pioneering new energy sources and materials. Clearly, acquiring vast amounts of information beyond human sensory perception would be impossible without corresponding sensor technologies. Many obstacles in fundamental research stem from difficulties in obtaining target information, and breakthroughs in certain fields often follow the development of novel, highly sensitive sensors. The progress of sensor technology frequently paves the way for interdisciplinary advancements.  

Sensors have already permeated a wide array of fields, including industrial production, space exploration, marine investigation, environmental protection, resource surveying, medical diagnostics, bioengineering, and even cultural heritage preservation. It is no exaggeration to say that nearly every modern project—from the vast expanse of space to the depths of the ocean, as well as complex engineering systems—relies on a diverse array of sensors.  

Thus, the critical role of sensor technology in economic development and societal progress is evident, prompting nations worldwide to prioritize advancements in this field. It is believed that in the near future, sensor technology will undergo a significant leap forward, reaching a new level commensurate with its importance.
## Project 1: Sensor Technology
### Task 1-1 Cognitive Sensors
## Task Book
| Task Number | 1-1       | Task Name          | Cognitive Sensors |
|-------------|-----------|--------------------|-------------------|
| Task Objective | |
| [Knowledge Objectives] Master the definition and functions of sensors; |
| Master the composition and classification of sensors; Master the general requirements and characteristics of sensors. |
| [Skill Objectives] Possess the application capability of sensors. [Quality Objectives] |
| Cultivate students' rigorous and conscientious work style. Task Description |
| This task aims to comprehensively understand the fundamental knowledge related to sensors. In groups, students will present the definition, functions, composition, classification, general requirements, and characteristics of sensors, laying the theoretical foundation for subsequent tasks. Implementation Instructions |
## Guidance Material
## Definition of Sensors
The national standard defines a sensor as a device or apparatus capable of sensing specified measured quantities and converting them into usable signals according to certain laws.
## 2. The Role of Sensors
The function of a sensor is to convert various signals from the external environment into electrical signals.  

The types of signals detected by sensors have significantly increased in recent times, leading to an extremely wide variety of sensors. To detect and control diverse signals, it is essential to obtain signals that are as simple and easy to process as possible—a requirement that only electrical signals can fulfill. Electrical signals can be easily amplified, fed back, filtered, differentiated, stored, and operated remotely. Therefore, as a functional module, a sensor can also be narrowly defined as "a component that transforms external input signals into electrical signals."  

The functions of sensors are often compared to the five major human sensory organs:  
① Photosensitive sensor — Vision;  
② Acoustic sensor — Hearing;  
③ Gas sensor — Smell;  
④ Chemical sensor — Taste;  
⑤ Fluid sensor — Touch.
## 3. Composition of Sensors
A sensor generally consists of three components: a sensing element, a conversion element, and a conversion circuit, as shown in Figure 1-1-1.
![](images/386f06e2c82647abcf0843da6469060faf4c7a3a8ebe71b36c5e3cce7760b6df.jpg)
1 - Figure 1 - Composition of Sensors  
(1) Sensing element: A component that directly senses the measured quantity and outputs a physical quantity with a deterministic relationship to the measured quantity.  
(2) Conversion element: A component that takes the output of the sensing element as input and converts the input into circuit parameters.  
(3) Conversion circuit: By connecting the circuit parameters to the conversion circuit, an electrical output can be obtained.  

In practice, some sensors have a relatively simple structure, consisting only of a sensing element, which directly outputs an electrical signal when sensing the measured quantity, such as the thermocouple to be studied in subsequent projects. Other sensors consist of sensing and conversion elements without a conversion circuit, while some sensors involve multiple conversion elements and require several stages of conversion.
## IV. Classification of Sensors
There are various classification methods for sensors, mainly including the following:  

(1) Classification by measured quantity: Sensors can be categorized into mechanical, optical, magnetic, geometric, kinematic, flow rate and flow volume, thermal, chemical, and biological sensors. This classification facilitates the selection and application of sensors.  

(2) Classification by working principle: Sensors can be divided into resistive, capacitive, inductive, photoelectric, grating, thermoelectric, piezoelectric, infrared, fiber-optic, ultrasonic, and laser sensors. This classification aids in sensor research, design, and the explanation of working principles.  

(3) Classification by sensitive material: Sensors can be classified as semiconductor, ceramic, quartz, optical fiber, metal, organic material, and polymer material sensors.  

The sensitive elements in sensors can be further categorized into 10 major types based on their fundamental sensing functions: thermal, photoelectric, gas, force, magnetic, humidity, acoustic, radiation, color, and taste-sensitive elements.  

(4) Classification by output signal type: Sensors can be divided into analog and digital sensors. Digital sensors are more convenient for computer integration and exhibit stronger anti-interference capabilities, such as pulse disk angle digital sensors and grating sensors. The digitization of sensors is a future development trend.  

(5) Classification by application field: Sensors can be categorized as industrial, agricultural, military, medical, scientific research, environmental, and household appliances sensors. Further classification by specific usage includes automotive, marine, aerospace, spacecraft, and disaster prevention sensors.  

(6) Classification by purpose: Sensors can be classified as measurement, monitoring, inspection, diagnostic, control, and analytical sensors.
## V. General Requirements for Sensors
Due to the differences in the principles, structures, usage environments, conditions, and purposes of various sensors, their technical specifications cannot be identical. However, some general requirements are fundamentally similar:  

(1) **Sufficient Capacity**: The working range or measurement range of the sensor should be sufficiently large, with a certain overload capability.  

(2) **High Sensitivity and Appropriate Accuracy**: The output signal should have a well-defined relationship (typically linear) with the measured signal, and the ratio should be large. The static and dynamic response accuracy must meet the requirements.  

(3) **Fast Response, Stable Operation, and High Reliability**: The sensor should respond quickly, operate stably, and exhibit good reliability.  

(4) **Strong Usability and Adaptability**: The sensor should be compact, lightweight, and require minimal actuation energy to minimize impact on the measured object. It should have low internal noise and high resistance to external interference. The output should preferably adopt a universal or standardized format for easy system integration.  

(5) **Economic Feasibility**: The sensor should be cost-effective, have a long lifespan, and be easy to use, maintain, and calibrate.  

Of course, sensors that fully meet all the above performance requirements are rare. A comprehensive evaluation should be conducted based on the specific application purpose, usage environment, measured object conditions, accuracy requirements, and operating principles.
## VI. Characteristics of Sensors
The characteristics of sensors mainly refer to the relationship between the input and output of the sensor, including static characteristics and dynamic characteristics.
### 1. Static Characteristics
The static characteristics of a sensor refer to the relationship between the output and input quantities of the sensor when measuring static signals. Since both the input and output quantities are independent of time, their relationship—i.e., the static characteristics of the sensor—can be described by an algebraic equation without time variables or by a characteristic curve plotted with the input quantity as the abscissa and the corresponding output quantity as the ordinate. The main parameters characterizing the static characteristics of a sensor include linearity, sensitivity, repeatability, resolution, hysteresis, drift, and threshold.
#### (1) Linearity.
Linearity refers to the degree of deviation between the actual relationship curve of the sensor output and the input quantity from the fitted straight line. It is defined as the ratio of the maximum deviation between the actual characteristic curve and the fitted straight line over the full range to the full-scale output value.
#### (2) Sensitivity.
Sensitivity is an important indicator of the static characteristics of a sensor. It is defined as the ratio of the increment in the output quantity to the corresponding increment in the input quantity that causes it.
#### (3) Repeatability.
Repeatability refers to the degree of inconsistency in the characteristic curves obtained when the sensor's input quantity undergoes continuous multiple full-scale variations in the same direction.
#### (4) Resolution.
When the input of a sensor slowly increases from a non-zero value, the output undergoes an observable change after exceeding a certain increment. This input increment is referred to as the resolution of the sensor, i.e., the minimum input increment.  

(5) Hysteresis.  

The phenomenon where the input-output characteristic curves of a sensor do not coincide during the input increasing from small to large (forward stroke) and decreasing from large to small (reverse stroke) is called hysteresis. For the same input signal magnitude, the output signals of the sensor during the forward and reverse strokes are unequal, and this difference is termed the hysteresis error.